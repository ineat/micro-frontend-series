import{r as e,e as t,n as r,h as a,T as s,a as i}from"./vendor.b49d7e37.js";var n=Object.defineProperty,o=Object.getOwnPropertyDescriptor,p=(e,t,r,a)=>{for(var s,i=a>1?void 0:a?o(t,r):t,p=e.length-1;p>=0;p--)(s=e[p])&&(i=(a?s(t,r,i):s(i))||i);return a&&i&&n(t,r,i),i};let h=class extends a{constructor(){super(),this.searchValue=""}render(){return s`
      <div class="sw-search">
        <input type="text"
          .value="${this.searchValue}"
          @change="${this._updateSearchValue}"/>
        ${""!==this.searchValue?s`
            <button class="btn-clear ${""===this.searchValue?"hide":""}" @click="${this._handleClear}">
              Clear
            </button>
          `:""}
        <button @click="${this._handleSearch}">
          Search
        </button>
      </div>
    `}_updateSearchValue(e){this.searchValue=e.target.value}_handleSearch(){let e=new CustomEvent("on-search",{detail:{searchValue:this.searchValue}});this.dispatchEvent(e)}_handleClear(){this.searchValue="";let e=new CustomEvent("on-clear",{detail:{searchValue:this.searchValue}});this.dispatchEvent(e)}};h.styles=e`
    .sw-search {
        display: flex;
        flex-direction: row;
        width: 100%;
      }

      .sw-search button {
        min-width: 6rem;
        margin-left: 1rem;
        border: 1px solid rgba(darkred, 0.7);
        background: darkred;
        color: #fff;
      }

      .sw-search button.btn-clear {
        border: 1px solid rgba(grey, 0.7);
        background: lightgrey;
        color: grey;
      }
      
      .sw-search input {
        width: 100%;
        height: 35px;
        padding-left: 1rem;
        border: 1px solid #eee;
        background: #fafafa;
        font-size: 1.125rem;
        
      }
  `,p([t({type:String,attribute:!1})],h.prototype,"searchValue",2),h=p([r("search-component")],h);var l=Object.defineProperty,c=Object.getOwnPropertyDescriptor,d=(e,t,r,a)=>{for(var s,i=a>1?void 0:a?c(t,r):t,n=e.length-1;n>=0;n--)(s=e[n])&&(i=(a?s(t,r,i):s(i))||i);return a&&i&&l(t,r,i),i};let u=class extends a{constructor(){super(),this.starship={name:""}}render(){return s`
      <li>
        <span>${this.starship.name}</span>
        <a class="btn btn-primary">Details</a>
      </li>
    `}};u.styles=e`
    li {
      list-style: none;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 2rem;
      border-bottom: 1px solid #efefef;
    }

    li > span {
        font-size: 1.2rem;
        font-weight: 500;
    }

    li > .btn {
      background: firebrick;
      color: white;
      padding: 0.25rem 0.75rem;
      border-radius: 0.5rem;
      border: 1px solid firebrick
    }
  `,d([t({type:Object})],u.prototype,"starship",2),u=d([r("starship-tile-component")],u);var g=Object.defineProperty,b=Object.getOwnPropertyDescriptor,m=(e,t,r,a)=>{for(var s,i=a>1?void 0:a?b(t,r):t,n=e.length-1;n>=0;n--)(s=e[n])&&(i=(a?s(t,r,i):s(i))||i);return a&&i&&g(t,r,i),i};let f=class extends a{constructor(){super(),this.pageNumber="1",this.current=1,this.pages=[]}render(){return s`
      <div class="pagination-wrapper">
        <ul>
          ${this.pages.map((e=>s`
              <li
                class="pagination-item ${this.current===e.id?"current":""}"
                @click="${()=>{this._handleClick(e.id)}}">
                <span>${e.text}</span>
              </li>
            `))}
        </ul>
      </div>
    `}connectedCallback(){super.connectedCallback(),this._createPagination()}performUpdate(){this._createPagination(),super.performUpdate()}_createPagination(){this.pages=[];for(let e=1;e<=parseInt(this.pageNumber);e++)this.pages=[...this.pages,{id:e,text:e}]}_handleClick(e){this.current=e;let t=new CustomEvent("on-paginate",{detail:{pageIndex:e}});this.dispatchEvent(t)}};f.styles=e`
    .pagination-wrapper {
      display: flex;
      flex-direction: row-reverse;
      padding: 1rem 0
    }
    
    .pagination-wrapper ul {
      display:flex;
      margin: 0;
      padding: 0;
      flex-direction: row;
      align-items: center;
    }
    
    .pagination-wrapper ul li {
      list-style: none;
      padding: 0.25rem .5rem;
      margin: 0 0.125rem;
      border: 1px solid #fff;
      cursor: pointer;
    }
    
    .pagination-wrapper ul li:hover {
      color: #fff;
      background: rgba(255, 34, 0, 0.5);
      border: 1px solid rgba(255, 34, 0, 0.5);
    }
    
    .pagination-wrapper ul li.current {
      border: 1px solid darkred;
      cursor: default;
      color: #fff;
      background: darkred;
    }
  `,m([t({type:String,attribute:!0})],f.prototype,"pageNumber",2),m([t({type:Number})],f.prototype,"current",2),m([t({type:Array})],f.prototype,"pages",2),f=m([r("pagination-component")],f);var y=Object.defineProperty,w=Object.getOwnPropertyDescriptor,x=(e,t,r,a)=>{for(var s,i=a>1?void 0:a?w(t,r):t,n=e.length-1;n>=0;n--)(s=e[n])&&(i=(a?s(t,r,i):s(i))||i);return a&&i&&y(t,r,i),i};let v=class extends a{constructor(){super(),this.title="Liste des vaisseaux",this.starships=[],this.pageNumber="",this.search="",this.resultPerPage=10}render(){return s`
      <h1>${this.title}</h1>
      <search-component
        @on-search="${this._onSearch}"
        @on-clear="${this._onClear}"
      ></search-component>
      ${this.starships.map((e=>s`
          <starship-tile-component .starship=${e}></starship-tile-component>
        `))}
      <pagination-component 
        @on-paginate="${this._onPaginate}"
        .pageNumber=${this.pageNumber}
      ></pagination-component>
    `}connectedCallback(){super.connectedCallback(),this._getStarship()}async _getStarship(e=1){const t=await fetch(`http://localhost:3010/starship?_page=${e}&_limit=${this.resultPerPage}`),r=t.headers.get("X-Total-Count"),a=await t.json();this.starships=a,this.pageNumber=""+Math.round(parseInt(r)/this.resultPerPage)}async _searchStarship(e=1){const t=await fetch(`http://localhost:3010/starship?q=${this.search}&_page=${e}&_limit=${this.resultPerPage}`),r=t.headers.get("X-Total-Count"),a=await t.json();this.starships=a,this.pageNumber=""+Math.round(parseInt(r)/this.resultPerPage)}_onPaginate(e){null!==this.search?this._searchStarship(e.detail.pageIndex):this._getStarship(e.detail.pageIndex)}_onSearch(e){this.search=e.detail.searchValue,this._searchStarship()}_onClear(){this.search="",this._getStarship()}};v.styles=e`
    h1 {
      display: block;
      width: 100%;
      text-align: center;
    }
  `,x([t({type:String})],v.prototype,"title",2),x([t({type:Array})],v.prototype,"starships",2),x([t({type:String})],v.prototype,"pageNumber",2),x([t({type:String})],v.prototype,"search",2),x([i()],v.prototype,"resultPerPage",2),v=x([r("sw-starship")],v);
